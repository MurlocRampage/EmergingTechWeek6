﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SmarterAIScript : MonoBehaviour
{
    private float lookRadius = 500f;

    public GameObject target;
    private NavMeshAgent agent;
    private Vector3 AIStartingPosition;
    private RaycastHit[] raycastHits;

    public enum State
    {
        PATROL,
        INVESTIGATE,
        CHASE,
        TAKECOVER,
        WEAPONSWITCH,
        SPEEDBOOST
    }

    public State state;
    private bool alive;

    public GameObject[] waypoints;
    private int waypointInt;
    public float patrolSpeed = 10.5f;
    public float chaseSpeed = 11f;
    public float dodgeSpeed = 100f;

    private Vector3 investigateSpot;
    private float timer = 0f;
    public float investigateWait = 10f;

    public float heightMultiplier = 0.8f;
    public float sightDis = 50f;

    // Start is called before the first frame update
    void Start()
    {
        AIStartingPosition = this.transform.position;
        agent = GetComponent<NavMeshAgent>();
        target = GameObject.FindGameObjectWithTag("Player");
        alive = true;
        waypoints = GameObject.FindGameObjectsWithTag("Waypoint");
        waypointInt = Random.Range(0, waypoints.Length);

        state = SmarterAIScript.State.PATROL;

        StartCoroutine("FSM");
    }

    IEnumerator FSM()
    {
        while(alive)
        {
            switch(state)
            {
                case State.PATROL:
                    Patrol();
                    break;
                case State.INVESTIGATE:
                    Investigate();
                    break;
                case State.CHASE:
                    Chase();
                    break;
                case State.TAKECOVER:
                    TakeCover();
                    break;
                case State.SPEEDBOOST:
                    SpeedBoost();
                    break;
                case State.WEAPONSWITCH:
                    WeaponSwitch();
                    break;

            }
            yield return null;
        }
    }

    void Patrol()
    {
        agent.speed = patrolSpeed;
        if(Vector3.Distance(this.transform.position, waypoints[waypointInt].transform.position) >= 2)
        {
            agent.SetDestination(waypoints[waypointInt].transform.position);
        }
        else if(Vector3.Distance(this.transform.position, waypoints[waypointInt].transform.position) <= 2)
        {
            waypointInt = Random.Range(0, waypoints.Length);
        }
        else
        {
            Debug.Log("Else is being called");
        }
    }

    void Investigate()
    {
        agent.SetDestination(this.transform.position);
        transform.LookAt(investigateSpot);
        if(timer >= investigateWait)
        {
            state = SmarterAIScript.State.PATROL;
            timer = 0;
        }
    }

    void Chase()
    {
        agent.speed = chaseSpeed;
        agent.SetDestination(target.transform.position);
    }

    void TakeCover()
    {

    }

    void SpeedBoost()
    {

    }

    void WeaponSwitch()
    {

    }

    private void OnTriggerEnter(Collider coll)
    {
        if(coll.tag == "Player")
        {
            state = SmarterAIScript.State.INVESTIGATE;
            investigateSpot = coll.gameObject.transform.position;
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        timer += Time.deltaTime;
        RaycastHit hit;
        Debug.DrawRay(transform.position + Vector3.up * heightMultiplier, transform.forward * sightDis, Color.red);
        Debug.DrawRay(transform.position + Vector3.up * heightMultiplier, (transform.forward + transform.right).normalized * sightDis, Color.red);
        //transform.right adding to forward with the sight dis makes a 45 degree angle and minusing it  gives the same but opposite percent.
        Debug.DrawRay(transform.position + Vector3.up * heightMultiplier, (transform.forward - transform.right).normalized * sightDis, Color.red);

        if (Physics.Raycast(transform.position + Vector3.up * heightMultiplier, transform.forward, out hit, sightDis))
        {
            if (hit.collider.gameObject.tag == "Player")
            {
                state = SmarterAIScript.State.CHASE;
                target = hit.collider.gameObject;
            }
            if (hit.collider.gameObject.tag == "Bullet")
            {
                state = SmarterAIScript.State.TAKECOVER;
            }
        }
        if (Physics.Raycast(transform.position + Vector3.up * heightMultiplier, (transform.forward + transform.right).normalized, out hit, sightDis))
        {
            if (hit.collider.gameObject.tag == "Player")
            {
                state = SmarterAIScript.State.CHASE;
                target = hit.collider.gameObject;
            }
            if (hit.collider.gameObject.tag == "Bullet")
            {
                state = SmarterAIScript.State.TAKECOVER;
            }
        }
        if (Physics.Raycast(transform.position + Vector3.up * heightMultiplier, (transform.forward - transform.right).normalized, out hit, sightDis))
        {
            if (hit.collider.gameObject.tag == "Player")
            {
                state = SmarterAIScript.State.CHASE;
                target = hit.collider.gameObject;
            }
            if (hit.collider.gameObject.tag == "Bullet")
            {
                state = SmarterAIScript.State.TAKECOVER;
            }
        }
    }


}
