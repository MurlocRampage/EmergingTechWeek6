﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class WeakAiScript : MonoBehaviour
{
    private float lookRadius = 500f;

    public Transform target;
    public NavMeshAgent agent;
    private bool isTagged;
    private Vector3 AIStartingPosition;

    // Start is called before the first frame update
    void Start()
    {
        isTagged = false;
        AIStartingPosition = this.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        float distance = Vector3.Distance(target.position, transform.position);

        if(isTagged)
        {
            if (distance <= lookRadius)
            {
                agent.SetDestination(target.position);
            }
        }
        
        else
        {
            Vector3 dirToPlayer = transform.position - target.position;
            Vector3 newPos = transform.position + dirToPlayer;
            agent.SetDestination(newPos);
        }
    }

    public void setTag(bool tagged)
    {
        isTagged = tagged;
    }

    public bool getTag()
    {
        return isTagged;
    }

    public void setPosition()
    {
        this.transform.position = AIStartingPosition;
    }
}
