﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour
{

    private GameObject player;
    public GameObject AI;
    private Vector3 playerStartingPoint;
    private int playerLives = 3;
    public Text playerLivesLeft;
    private bool PlayerTagged;
    private int AILivesLeft;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        playerStartingPoint = player.transform.position;
        PlayerTagged = false;
    }

    // Update is called once per frame
    void Update()
    {
        playerLivesLeft.text = "player has " + playerLives + " Left!";

        if (playerLives < 1)
        {
            //Player loses
        }

        MovementHandler();
    }
    private void MovementHandler()
    {
        if (Input.GetKey(KeyCode.W))
        {
            player.transform.position = new Vector3(player.transform.position.x, player.transform.position.y, player.transform.position.z + .5f);
        }

        if (Input.GetKey(KeyCode.S))
        {
            player.transform.position = new Vector3(player.transform.position.x, player.transform.position.y, player.transform.position.z - .5f);
        }

        if (Input.GetKey(KeyCode.A))
        {
            player.transform.position = new Vector3(player.transform.position.x - .5f, player.transform.position.y, player.transform.position.z);
        }

        if (Input.GetKey(KeyCode.D))
        {
            player.transform.position = new Vector3(player.transform.position.x + .5f, player.transform.position.y, player.transform.position.z);
        }
    }
    
    public void OnCollisionEnter(Collision col)
    {
        if(col.gameObject.tag == "AI")
        {
            if(AI.GetComponent<WeakAiScript>().getTag() == true)
            {
                AI.GetComponent<WeakAiScript>().setTag(false);
                PlayerTagged = true;
                AI.GetComponent<WeakAiScript>().setPosition();
                this.transform.position = playerStartingPoint;
            }
            else if (AI.GetComponent<WeakAiScript>().getTag() == false)
            {
                AI.GetComponent<WeakAiScript>().setTag(true);
                PlayerTagged = false;
                AI.GetComponent<WeakAiScript>().setPosition();
                this.transform.position = playerStartingPoint;
            }
        }
    }
}
