﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SmarterAIScript : MonoBehaviour
{
    private float lookRadius = 500f;

    public GameObject target;
    public NavMeshAgent agent;
    private Vector3 AIStartingPosition;

    public enum State
    {
        PATROL,
        CHASE,
        TAKECOVER,
        WEAPONSWITCH,
        SPEEDBOOST
    }

    public State state;
    private bool alive;

    public GameObject[] waypoints;
    private int waypointInt;
    public float patrolSpeed;
    public float chaseSpeed;
    public float dodgeSpeed;

    private Vector3

    // Start is called before the first frame update
    void Start()
    {
        AIStartingPosition = this.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
